import { Cabecera } from "./app/contenedores/Cabecera";
import { Home } from "./app/contenedores/Home";
import "./assets/css/main.css";
import "./assets/css/variables-blue.css";
import "./assets/css/variables-green.css";
import "./assets/css/variables-orange.css";
import "./assets/css/variables-pink.css";
import "./assets/css/variables-purple.css";
import "./assets/css/variables-red.css";
import "./assets/css/variables.css";
import "./App.css";
import { AcercaDe } from "./app/contenedores/AcercaDe";
import { Servicios } from "./app/contenedores/Servicios";

function App() {
  return (
    <div className="App">
      <Cabecera />
      <Home />
      <AcercaDe />
      <Servicios />
    </div>
  );
}

export default App;
