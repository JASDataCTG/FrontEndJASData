import imgBigData from "../../assets/images/inicio/BigData.png"

export const Home = () => {
  return (
    <div>
      <section
        id="hero-animated"
        className="hero-animated d-flex align-items-center"
      >
        <div
          className="container d-flex flex-column justify-content-center align-items-center text-center position-relative aos-init aos-animate"
          data-aos="zoom-out"
        >
          <img
            src={imgBigData}
            className="img-fluid animated"
          />
          <h2>
            Bienvenido a <span>JASData</span>
          </h2>
          <p>
            Servicios en Ciencia de Datos para la gestión eficiente de organizaciones <span>Data Driven</span> (Gestionadas por Datos)
          </p>
          <p>Inteligencia de Negocios - Visualizaciones Interactivas - Machine Learning</p>
          <div className="d-flex">
            <a href="#about" className="btn-get-started scrollto">
              Conócenos
            </a>
            
          </div>
        </div>
      </section>
    </div>
  );
};
