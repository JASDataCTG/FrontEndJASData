import Serv1 from "../../assets/images/servicios/services-1.jpg";
import Serv2 from "../../assets/images/servicios/services-2.jpg";
import Serv3 from "../../assets/images/servicios/services-3.jpg";
import Serv4 from "../../assets/images/servicios/services-4.jpg";
import Serv5 from "../../assets/images/servicios/services-5.jpg";
import Serv6 from "../../assets/images/servicios/services-6.jpg";

export const Servicios = () => {
  return (
    <div>
      <section id="services" className="services">
        <div className="container aos-init aos-animate" data-aos="fade-up">
          <div className="section-header">
            <h2>Nuestros servicios</h2>
            <p>
              Ea vitae aspernatur deserunt voluptatem impedit deserunt magnam
              occaecati dssumenda quas ut ad dolores adipisci aliquam.
            </p>
          </div>

          <div className="row gy-5">
            <div
              className="col-xl-4 col-md-6 aos-init aos-animate"
              data-aos="zoom-in"
              data-aos-delay="200"
            >
              <div className="service-item">
                <div className="img">
                  <img
                    src={Serv1}
                    className="img-fluid"
                    alt=""
                  />
                </div>
                <div className="details position-relative">
                  <div className="icon">
                    <i className="bi bi-bar-chart-steps"></i>
                  </div>
                  <a href="/#" className="stretched-link">
                    <h3>Inteligencia de Negocios</h3>
                  </a>
                  <p>
                    Desarrollo de tableros de mando (dashboard) para el control y la toma de decisiones empresariales.
                  </p>
                </div>
              </div>
            </div>
            {/* End Service Item */}

            <div
              className="col-xl-4 col-md-6 aos-init aos-animate"
              data-aos="zoom-in"
              data-aos-delay="300"
            >
              <div className="service-item">
                <div className="img">
                  <img
                    src={Serv2}
                    className="img-fluid"
                    alt=""
                  />
                </div>
                <div className="details position-relative">
                  <div className="icon">
                    <i className="bi bi-cpu"></i>
                  </div>
                  <a href="#" className="stretched-link">
                    <h3>Modelos de Machine Learning</h3>
                  </a>
                  <p>
                    Modelado de datos con la metodologíá CRISP-DM para implementación de sistemas de predicción o clasificación. 
                  </p>
                </div>
              </div>
            </div>
            {/* End Service Item */}

            <div
              className="col-xl-4 col-md-6 aos-init aos-animate"
              data-aos="zoom-in"
              data-aos-delay="400"
            >
              <div className="service-item">
                <div className="img">
                  <img
                    src={Serv3}
                    className="img-fluid"
                    alt=""
                  />
                </div>
                <div className="details position-relative">
                  <div className="icon">
                    <i className="bi bi-easel"></i>
                  </div>
                  <a href="#" className="stretched-link">
                    <h3>Ledo Markt</h3>
                  </a>
                  <p>
                    Ut excepturi voluptatem nisi sed. Quidem fuga consequatur.
                    Minus ea aut. Vel qui id voluptas adipisci eos earum
                    corrupti.
                  </p>
                </div>
              </div>
            </div>
            {/* End Service Item */}

            <div
              className="col-xl-4 col-md-6 aos-init aos-animate"
              data-aos="zoom-in"
              data-aos-delay="500"
            >
              <div className="service-item">
                <div className="img">
                  <img
                    src={Serv4}
                    className="img-fluid"
                    alt=""
                  />
                </div>
                <div className="details position-relative">
                  <div className="icon">
                    <i className="bi bi-bounding-box-circles"></i>
                  </div>
                  <a href="#" className="stretched-link">
                    <h3>Asperiores Commodit</h3>
                  </a>
                  <p>
                    Non et temporibus minus omnis sed dolor esse consequatur.
                    Cupiditate sed error ea fuga sit provident adipisci neque.
                  </p>
                  <a href="#" className="stretched-link"></a>
                </div>
              </div>
            </div>
            {/* End Service Item */}

            <div
              className="col-xl-4 col-md-6 aos-init aos-animate"
              data-aos="zoom-in"
              data-aos-delay="600"
            >
              <div className="service-item">
                <div className="img">
                  <img
                    src={Serv5}
                    className="img-fluid"
                    alt=""
                  />
                </div>
                <div className="details position-relative">
                  <div className="icon">
                    <i className="bi bi-calendar4-week"></i>
                  </div>
                  <a href="#" className="stretched-link">
                    <h3>Velit Doloremque</h3>
                  </a>
                  <p>
                    Cumque et suscipit saepe. Est maiores autem enim facilis ut
                    aut ipsam corporis aut. Sed animi at autem alias eius
                    labore.
                  </p>
                  <a href="#" className="stretched-link"></a>
                </div>
              </div>
            </div>
            {/* End Service Item */}

            <div
              className="col-xl-4 col-md-6 aos-init aos-animate"
              data-aos="zoom-in"
              data-aos-delay="700"
            >
              <div className="service-item">
                <div className="img">
                  <img
                    src={Serv6}
                    className="img-fluid"
                    alt=""
                  />
                </div>
                <div className="details position-relative">
                  <div className="icon">
                    <i className="bi bi-chat-square-text"></i>
                  </div>
                  <a href="#" className="stretched-link">
                    <h3>Dolori Architecto</h3>
                  </a>
                  <p>
                    Hic molestias ea quibusdam eos. Fugiat enim doloremque aut
                    neque non et debitis iure. Corrupti recusandae ducimus enim.
                  </p>
                  <a href="#" className="stretched-link"></a>
                </div>
              </div>
            </div>
            {/* End Service Item */}
          </div>
        </div>
      </section>
    </div>
  );
};
